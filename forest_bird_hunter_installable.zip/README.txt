FOREST BIRD HUNTER — INSTALLABLE OFFLINE GAME

Files:
- index.html: the game
- manifest.json: install metadata
- sw.js: offline cache service worker

To play immediately:
1. Open index.html in a modern browser (some browsers restrict sound until you tap Enter the Forest).

To install as an app on Android:
1. Upload these three files to an HTTPS static host (for example GitHub Pages or Netlify).
2. Open the hosted address in Chrome.
3. Use Chrome menu (⋮) > Install app / Add to Home screen.
4. Launch it once while online. The service worker caches the game; it can then run offline.

Note: Installable PWAs require HTTPS (or localhost). Opening the HTML file directly is playable but does not enable PWA installation/offline service-worker caching.
Controls:
- Arrow pad: move forward/back/strafe and turn.
- Drag the forest view: look around.
- FIRE: shoot toward the center crosshair.
- Bird calls and leafy footsteps are generated locally with Web Audio.
